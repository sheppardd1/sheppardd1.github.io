
function fm_spectrum ( beta )
% Computes and displays the spectrum of a single-tone FM signal.
% Spectrum is computed using both the fft() function and Bessel's Equations

    close all;
    %% define the parameters and the signal
    T = 1e-9;           % Sampling period
    fs = 1/T;           % sampling frequency
    t = 0:T:0.0005-T;   % time to plot signal over
    fc = 150e3;         % carrier frequency (arbitrary)
    Ac = 1;             % amplitude of carrier (arbitrary)
    fm = 2e3;           % single-tone message frequency (arbitrary)
    % the FM signal
    s = Ac * cos(2*pi*fc*t + beta*sin(2*pi*fm*t));
    % plot the signal
    figure(1);
    subplot(3,1,1);
    plot(t, s);
    title(['Modulated Signal with \beta = ', num2str(beta)]);
    sgtitle(['Properties of s(t)= ', num2str(Ac), 'cos[2\pi', num2str(fc), ...
        't + ', num2str(beta), 'sin(2\pi' num2str(fm), 't)]']);
    xlabel('time (s)');
    ylabel('amplitude');
    grid();
    
    %% compute spectrum using Bessel's Functions
    f = 0:fm:2*fc;          % This is the frequency range to look at
    S = zeros(1,length(f));     % initialize the spectrum to all 0
    
    % Iterate for many values of n
    % Technically, n should be from -infinity to +infinity, but -1000 to
    % 1000 is good enough
    for n = -1000:1000
        S = S + Ac * abs(0.5 * besselj(n,beta) * ...
            (find_dirac(-(fc+n*fm), f) + find_dirac((fc+n*fm), f)));
    end
    subplot(3,1,2);
    % plot results
    bar(f, S, 0.3);
    xlim([0 2*fc]);
    ylim([0 max(S)*1.1]);
    xlabel('frequency (Hz)');
    ylabel('magnitude');
    grid();
    title("Spectrum From Bessel's Function");

    %% compute spectrum using the fft function
    L = length(t);      % size of time vector
    dft = fft(s);       % get fft of signal
    P2 = abs(dft/L);    % get 2-sided spectrul
    P1 = P2(1:L/2+1);   % extract 1-sided spectrum
    f = fs*(0:(L/2))/L; % set frequency range
    subplot(3,1,3);
    % plot results
    bar(f,P1, 0.3) 
    xlim([0 2*fc]);
    ylim([0 max(P1)*1.1]);
    xlabel('frequency (Hz)');
    ylabel('magnitude');
    grid();
    title("Spectrum from MATLAB's FFT Function");


end

function d = find_dirac ( number, x )
% Finds spot in vector x where number == -x without altering x
% Creates a mask to multiply the original signal with to remove all else

    d = zeros(1, length(x));    % initialize d to all 0s
    for i = 1:length(x)
        if ( x(i) + number == 0)    % find value(s) in x 
            d(i) = 1;
        end
    end

    %{
    Usage Example:
        t = [ 0 1 2 3 4 5 ];
        d = find_dirac(-4,a);   ---> equivalent of \delta(a-4)
    result: d = [ 0 0 0 0 1 0 ]
    %}
end
