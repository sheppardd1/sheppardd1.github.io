% VLSI Homework 1 Problem 2
% David Sheppard
% 10/1/2019

% Plot Ids vs. Vds for varying Vgs values

% Given:
W_over_L = 2;                   % unitless
mobility = 350;                 % (cm^2)/(V*s)
V_t = 0.7;                      % V
V_ds = 0:0.01:5;                % V
t_ox = 100*10^-8;               % cm
V_gs = [0 1 2 3 4 5];           % V
E_o = 8.85 * 10^-14;            % F/cm
E_relative = 3.9;               % (for silicon)

% Derived:
C_ox = (E_o * E_relative)/ t_ox;     % F
beta = mobility * C_ox * W_over_L;    % F*(cm^2)/(V*s)

% initialize Ids for testing:
I_ds = zeros(1,length(V_ds));         % A

% open figure
figure(1);
for i=1:length(V_gs)     % iterate for Vgs values
    
    for j=1:length(V_ds) % iterate for Vds values
        
        % if in Cutoff
        if (V_gs(i) < V_t)
            I_ds(j) = 0;
            
        % if in Linear Region
        elseif(V_ds(j) < V_gs(i) - V_t)
            I_ds(j) = beta * (V_gs(i) - V_t - (V_ds(j)/2)) * V_ds(j);
            
        % if in Saturation Region:
        else
            I_ds(j) = (beta/2) * (V_gs(i)-V_t)^2;
            
        end
        
        % convert to mA
        I_ds(j) = I_ds(j) * 1000;
        
    end
    
    % plot the series
    plot(V_ds, I_ds, 'Linewidth', 2);
    hold on;    % wait for other series
end

% formatting plot
title('I_{ds} vs V_{ds}');
grid();
xlabel('V_{ds} (V)');
ylabel('I_{ds} (mA)');
legend({'V_{gs}=0 V','V_{gs}=1 V', 'V_{gs}=2 V',...
    'V_{gs}=3 V','V_{gs}=4 V', 'V_{gs}=5 V'},'Location','northwest')
hold off;

